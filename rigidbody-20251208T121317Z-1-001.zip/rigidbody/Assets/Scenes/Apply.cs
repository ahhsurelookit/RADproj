using UnityEngine;

public class Apply : MonoBehaviour
{
    public float explosionForce = 500f;
    public float explosionRadius = 5f;
    public float upwardsModifier = 2f;

    private Rigidbody ourRigidbody;

    void Start()
    {
        ourRigidbody = GetComponent<Rigidbody>();
    }

    void Update()
    {
        // This uses the old Input system (works when Active Input Handling = Both)
        if (Input.GetKeyDown(KeyCode.Space))
        {
            Debug.Log("SPACE pressed, applying explosion");

            if (ourRigidbody == null) return;

            // Explosion point just below the cube so it gets pushed UP
            Vector3 explosionPos = transform.position + Vector3.down * 0.5f;

            ourRigidbody.AddExplosionForce(
                explosionForce,
                explosionPos,
                explosionRadius,
                upwardsModifier,
                ForceMode.Impulse
            );
        }
    }
}
