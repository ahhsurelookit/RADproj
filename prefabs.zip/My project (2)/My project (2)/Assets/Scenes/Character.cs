using Game.Scripts;
using UnityEngine;

public class BulletScript1 : MonoBehaviour
{
    [SerializeField] private float bulletSpeed = 20f; // Speed of the bullet

    private void Update()
    {
        transform.position += transform.forward * bulletSpeed * Time.deltaTime;
    }

    private void OnCollisionEnter(Collision collision)
    {
        Health health = collision.gameObject.GetComponent<Health>();
        if (health != null)
        {
            health.takeDamage(10); // Inflict 10 damage on hit
        }

        Destroy(gameObject); // Destroy the bullet on impact
    }
}
