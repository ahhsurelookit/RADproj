using UnityEngine;

namespace Game.Scripts
{
    public class Health : MonoBehaviour
    {
        public int maxHealth = 100;
        int currentHealth;

        void Start()
        {
            currentHealth = maxHealth;
        }

        public void takeDamage(int amount)
        {
            currentHealth -= amount;
            Debug.Log(gameObject.name + " took " + amount + " damage. Health: " + currentHealth);

            if (currentHealth <= 0)
            {
                Destroy(gameObject);
            }
        }
    }
}
